module.exports = {
    "secret": "005c9780fe7c11eb89b4e39719de58a5"
}

//UUID 암호 문자열